MOVIE TRAILER Website

This is a simple movie trailer website that shows a couple of movies that I personally like. In order to initiate the website, just click on "entertaiment_center.py" and click on any movie that catches your eye.
